

<div class="addcandidate" >

<form method="post" action="functions.php">
<input type="text" name="first_name" placeholder="First Name" required/><br /><br />
<input type="text" name="last_name" placeholder="Last Name" required/><br /><br />
<input type="text" name="admno" placeholder="Admission Number" required/><br /><br />
<input type="text" name="regno" placeholder="Registration Number" required/><br /><br />
<input type="Email" name="email" placeholder="Email" required/><br /><br />
<input type="password" name="password" placeholder="Password" required/><br /><br />
<input type="submit" name="submitregdetailsstudents" Value="Register"/><br /><br />

	</form>
	</div>



