

<div class="addcandidate" >

<form method="post" action="functions.php" >

<input type="text" name="position" placeholder="Position" required/><br /><br />

<input type="submit" name="submitAddPosition" value="Add Position"/>
</form>
	</div>
