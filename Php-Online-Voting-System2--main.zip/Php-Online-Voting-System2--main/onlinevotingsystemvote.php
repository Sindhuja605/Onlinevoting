<?php
include("databaseconnect.php");

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

<div class="studentvote">
    <div class="votingDropDown">
        <form method="post" action="onlinevotingsystem.php?onlinevotingsystemvote" id="onlinevotingsystem">
            <select name="selectCandidate">
                <?php
                $sqlQry = "SELECT * FROM position";
                $qry = mysqli_query($connect, $sqlQry);
                while ($posrow = mysqli_fetch_array($qry)) {
                    echo "<option value='" . htmlspecialchars($posrow['Position']) . "'>" . htmlspecialchars($posrow['Position']) . "</option>";
                }
                ?>
            </select>
            <input type="submit" name="searchcandidates" value="Show Candidate" />
        </form>
    </div>

    <div id="alreadyVoted">
        <p>You Have Voted For:
            <ol>
                <?php
                $sessregnosels = $_SESSION['regno'];
                $sel = "SELECT * FROM votes WHERE regno = ?";
                $stmt = mysqli_prepare($connect, $sel);
                mysqli_stmt_bind_param($stmt, 's', $sessregnosels);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);

                while ($rowsels = mysqli_fetch_array($result)) {
                    echo "<li>" . htmlspecialchars($rowsels['Position']) . "</li>";
                }

                mysqli_stmt_close($stmt);
                ?>
            </ol>
        </p>
    </div>

    <?php
    if (isset($_POST['searchcandidates'])) {
        $selectedPosition = $_POST['selectCandidate'];

        $sql = "SELECT * FROM candidates WHERE position = ?";
        $stmt = mysqli_prepare($connect, $sql);
        mysqli_stmt_bind_param($stmt, 's', $selectedPosition);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        while ($row = mysqli_fetch_array($result)) {
            echo "<div id='candidatesdiv'>";
            echo htmlspecialchars($row['first_name']) . " <br>";
            echo htmlspecialchars($row['last_name']) . "<br>";
            echo htmlspecialchars($row['position']) . "<br><br>";
            echo "<i class='fa fa-user-circle-o fa-5x' aria-hidden='true'></i>";
            echo "<div class='votingsection'>";
            echo "<form method='POST' action=''>";
            echo "<input type='hidden' name='submitvotesid' value='" . htmlspecialchars($row['candidate_id']) . "'/>";
            echo "<input type='hidden' name='candfirstname' value='" . htmlspecialchars($row['first_name']) . "'/>";
            echo "<input type='hidden' name='positionhidd' value='" . htmlspecialchars($row['position']) . "'/>";
            echo "<input type='submit' name='submitvotes' value='Vote' />";
            echo "</form>";
            echo "</div>";
            echo "</div>";
        }

        mysqli_stmt_close($stmt);
    }

    if (isset($_POST['submitvotes'])) {
        $sessregno = $_SESSION['regno'];
        $positionhidd = $_POST['positionhidd'];
        $submitvotesid = $_POST['submitvotesid'];

        $selvtes = "SELECT * FROM votes WHERE Position = ? AND regno = ?";
        $stmt = mysqli_prepare($connect, $selvtes);
        mysqli_stmt_bind_param($stmt, 'ss', $positionhidd, $sessregno);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        $rows = mysqli_stmt_num_rows($stmt);

        if ($rows == 0) {
            $vote = "INSERT INTO votes (Position, candidate_id, regno, votesnumber) VALUES (?, ?, ?, 1)";
            $stmt = mysqli_prepare($connect, $vote);
            mysqli_stmt_bind_param($stmt, 'sis', $positionhidd, $submitvotesid, $sessregno);
            $voteqry = mysqli_stmt_execute($stmt);

            if ($voteqry) {
                echo '<div class="w3-container w3-section w3-green">
                    <span onclick="this.parentElement.style.display=\'none\'" class="w3-closebtn">&times;</span>
                    <h3>Info!</h3>
                    <p>Voted successfully</p>
                </div>';
            } else {
                echo '<div class="w3-container w3-section w3-red">
                    <span onclick="this.parentElement.style.display=\'none\'" class="w3-closebtn">&times;</span>
                    <h3>Info!</h3>
                    <p>Error voting. Please try again.</p>
                </div>';
            }
        } else {
            echo '<div class="w3-container w3-section w3-red">
                <span onclick="this.parentElement.style.display=\'none\'" class="w3-closebtn">&times;</span>
                <h3>Info!</h3>
                <p>You can\'t vote twice in the same position. Select another position from the dropdown menu!</p>
            </div>';
        }

        mysqli_stmt_close($stmt);
    }

    mysqli_close($connect);
    ?>
</div>
